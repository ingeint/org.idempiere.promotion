/******************************************************************************
 * Product: iDempiere ERP & CRM Smart Business Solution                       *
 * Copyright (C) 1999-2012 ComPiere, Inc. All Rights Reserved.                *
 * This program is free software, you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY, without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program, if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 * For the text or an alternative of this public license, you may reach us    *
 * ComPiere, Inc., 2620 Augustine Dr. #245, Santa Clara, CA 95054, USA        *
 * or via info@compiere.org or http://www.compiere.org/license.html           *
 *****************************************************************************/
/** Generated Model - DO NOT CHANGE */
package org.idempiere.model;

import java.sql.ResultSet;
import java.util.Properties;
import org.compiere.model.*;
import org.compiere.util.KeyNamePair;

/** Generated Model for M_PromotionGroup
 *  @author iDempiere (generated)
 *  @version Release 12 - $Id$ */
@org.adempiere.base.Model(table="M_PromotionGroup")
public class X_M_PromotionGroup extends PO implements I_M_PromotionGroup, I_Persistent
{

	/**
	 *
	 */
	private static final long serialVersionUID = 20240617L;

    /** Standard Constructor */
    public X_M_PromotionGroup (Properties ctx, int M_PromotionGroup_ID, String trxName)
    {
      super (ctx, M_PromotionGroup_ID, trxName);
      /** if (M_PromotionGroup_ID == 0)
        {
			setM_PromotionGroup_ID (0);
			setName (null);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroup (Properties ctx, int M_PromotionGroup_ID, String trxName, String ... virtualColumns)
    {
      super (ctx, M_PromotionGroup_ID, trxName, virtualColumns);
      /** if (M_PromotionGroup_ID == 0)
        {
			setM_PromotionGroup_ID (0);
			setName (null);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroup (Properties ctx, String M_PromotionGroup_UU, String trxName)
    {
      super (ctx, M_PromotionGroup_UU, trxName);
      /** if (M_PromotionGroup_UU == null)
        {
			setM_PromotionGroup_ID (0);
			setName (null);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroup (Properties ctx, String M_PromotionGroup_UU, String trxName, String ... virtualColumns)
    {
      super (ctx, M_PromotionGroup_UU, trxName, virtualColumns);
      /** if (M_PromotionGroup_UU == null)
        {
			setM_PromotionGroup_ID (0);
			setName (null);
        } */
    }

    /** Load Constructor */
    public X_M_PromotionGroup (Properties ctx, ResultSet rs, String trxName)
    {
      super (ctx, rs, trxName);
    }

    /** AccessLevel
      * @return 3 - Client - Org
      */
    protected int get_AccessLevel()
    {
      return accessLevel.intValue();
    }

    /** Load Meta Data */
    protected POInfo initPO (Properties ctx)
    {
      POInfo poi = POInfo.getPOInfo (ctx, Table_ID, get_TrxName());
      return poi;
    }

    public String toString()
    {
      StringBuilder sb = new StringBuilder ("X_M_PromotionGroup[")
        .append(get_ID()).append(",Name=").append(getName()).append("]");
      return sb.toString();
    }

	/** Set Description.
		@param Description Optional short description of the record
	*/
	public void setDescription (String Description)
	{
		set_Value (COLUMNNAME_Description, Description);
	}

	/** Get Description.
		@return Optional short description of the record
	  */
	public String getDescription()
	{
		return (String)get_Value(COLUMNNAME_Description);
	}

	/** Set Promotion Group.
		@param M_PromotionGroup_ID Promotion Group
	*/
	public void setM_PromotionGroup_ID (int M_PromotionGroup_ID)
	{
		if (M_PromotionGroup_ID < 1)
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroup_ID, null);
		else
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroup_ID, Integer.valueOf(M_PromotionGroup_ID));
	}

	/** Get Promotion Group.
		@return Promotion Group	  */
	public int getM_PromotionGroup_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_M_PromotionGroup_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set M_PromotionGroup_UU.
		@param M_PromotionGroup_UU M_PromotionGroup_UU
	*/
	public void setM_PromotionGroup_UU (String M_PromotionGroup_UU)
	{
		set_Value (COLUMNNAME_M_PromotionGroup_UU, M_PromotionGroup_UU);
	}

	/** Get M_PromotionGroup_UU.
		@return M_PromotionGroup_UU	  */
	public String getM_PromotionGroup_UU()
	{
		return (String)get_Value(COLUMNNAME_M_PromotionGroup_UU);
	}

	/** Set Name.
		@param Name Alphanumeric identifier of the entity
	*/
	public void setName (String Name)
	{
		set_Value (COLUMNNAME_Name, Name);
	}

	/** Get Name.
		@return Alphanumeric identifier of the entity
	  */
	public String getName()
	{
		return (String)get_Value(COLUMNNAME_Name);
	}

    /** Get Record ID/ColumnName
        @return ID/ColumnName pair
      */
    public KeyNamePair getKeyNamePair()
    {
        return new KeyNamePair(get_ID(), getName());
    }
}