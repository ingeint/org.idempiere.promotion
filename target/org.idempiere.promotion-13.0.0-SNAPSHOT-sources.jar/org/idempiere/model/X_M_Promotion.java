/******************************************************************************
 * Product: iDempiere ERP & CRM Smart Business Solution                       *
 * Copyright (C) 1999-2012 ComPiere, Inc. All Rights Reserved.                *
 * This program is free software, you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY, without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program, if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 * For the text or an alternative of this public license, you may reach us    *
 * ComPiere, Inc., 2620 Augustine Dr. #245, Santa Clara, CA 95054, USA        *
 * or via info@compiere.org or http://www.compiere.org/license.html           *
 *****************************************************************************/
/** Generated Model - DO NOT CHANGE */
package org.idempiere.model;

import java.sql.ResultSet;
import java.util.Properties;
import org.compiere.model.*;
import org.compiere.util.KeyNamePair;

/** Generated Model for M_Promotion
 *  @author iDempiere (generated)
 *  @version Release 12 - $Id$ */
@org.adempiere.base.Model(table="M_Promotion")
public class X_M_Promotion extends PO implements I_M_Promotion, I_Persistent
{

	/**
	 *
	 */
	private static final long serialVersionUID = 20240617L;

    /** Standard Constructor */
    public X_M_Promotion (Properties ctx, int M_Promotion_ID, String trxName)
    {
      super (ctx, M_Promotion_ID, trxName);
      /** if (M_Promotion_ID == 0)
        {
			setM_Promotion_ID (0);
			setName (null);
			setPromotionPriority (0);
// 0
        } */
    }

    /** Standard Constructor */
    public X_M_Promotion (Properties ctx, int M_Promotion_ID, String trxName, String ... virtualColumns)
    {
      super (ctx, M_Promotion_ID, trxName, virtualColumns);
      /** if (M_Promotion_ID == 0)
        {
			setM_Promotion_ID (0);
			setName (null);
			setPromotionPriority (0);
// 0
        } */
    }

    /** Standard Constructor */
    public X_M_Promotion (Properties ctx, String M_Promotion_UU, String trxName)
    {
      super (ctx, M_Promotion_UU, trxName);
      /** if (M_Promotion_UU == null)
        {
			setM_Promotion_ID (0);
			setName (null);
			setPromotionPriority (0);
// 0
        } */
    }

    /** Standard Constructor */
    public X_M_Promotion (Properties ctx, String M_Promotion_UU, String trxName, String ... virtualColumns)
    {
      super (ctx, M_Promotion_UU, trxName, virtualColumns);
      /** if (M_Promotion_UU == null)
        {
			setM_Promotion_ID (0);
			setName (null);
			setPromotionPriority (0);
// 0
        } */
    }

    /** Load Constructor */
    public X_M_Promotion (Properties ctx, ResultSet rs, String trxName)
    {
      super (ctx, rs, trxName);
    }

    /** AccessLevel
      * @return 3 - Client - Org
      */
    protected int get_AccessLevel()
    {
      return accessLevel.intValue();
    }

    /** Load Meta Data */
    protected POInfo initPO (Properties ctx)
    {
      POInfo poi = POInfo.getPOInfo (ctx, Table_ID, get_TrxName());
      return poi;
    }

    public String toString()
    {
      StringBuilder sb = new StringBuilder ("X_M_Promotion[")
        .append(get_ID()).append(",Name=").append(getName()).append("]");
      return sb.toString();
    }

	public org.compiere.model.I_C_Campaign getC_Campaign() throws RuntimeException
	{
		return (org.compiere.model.I_C_Campaign)MTable.get(getCtx(), org.compiere.model.I_C_Campaign.Table_ID)
			.getPO(getC_Campaign_ID(), get_TrxName());
	}

	/** Set Campaign.
		@param C_Campaign_ID Marketing Campaign
	*/
	public void setC_Campaign_ID (int C_Campaign_ID)
	{
		if (C_Campaign_ID < 1)
			set_Value (COLUMNNAME_C_Campaign_ID, null);
		else
			set_Value (COLUMNNAME_C_Campaign_ID, Integer.valueOf(C_Campaign_ID));
	}

	/** Get Campaign.
		@return Marketing Campaign
	  */
	public int getC_Campaign_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_C_Campaign_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set Description.
		@param Description Optional short description of the record
	*/
	public void setDescription (String Description)
	{
		set_Value (COLUMNNAME_Description, Description);
	}

	/** Get Description.
		@return Optional short description of the record
	  */
	public String getDescription()
	{
		return (String)get_Value(COLUMNNAME_Description);
	}

	/** Set Promotion.
		@param M_Promotion_ID Promotion
	*/
	public void setM_Promotion_ID (int M_Promotion_ID)
	{
		if (M_Promotion_ID < 1)
			set_ValueNoCheck (COLUMNNAME_M_Promotion_ID, null);
		else
			set_ValueNoCheck (COLUMNNAME_M_Promotion_ID, Integer.valueOf(M_Promotion_ID));
	}

	/** Get Promotion.
		@return Promotion	  */
	public int getM_Promotion_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_M_Promotion_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set M_Promotion_UU.
		@param M_Promotion_UU M_Promotion_UU
	*/
	public void setM_Promotion_UU (String M_Promotion_UU)
	{
		set_Value (COLUMNNAME_M_Promotion_UU, M_Promotion_UU);
	}

	/** Get M_Promotion_UU.
		@return M_Promotion_UU	  */
	public String getM_Promotion_UU()
	{
		return (String)get_Value(COLUMNNAME_M_Promotion_UU);
	}

	/** Set Name.
		@param Name Alphanumeric identifier of the entity
	*/
	public void setName (String Name)
	{
		set_Value (COLUMNNAME_Name, Name);
	}

	/** Get Name.
		@return Alphanumeric identifier of the entity
	  */
	public String getName()
	{
		return (String)get_Value(COLUMNNAME_Name);
	}

    /** Get Record ID/ColumnName
        @return ID/ColumnName pair
      */
    public KeyNamePair getKeyNamePair()
    {
        return new KeyNamePair(get_ID(), getName());
    }

	/** Set Relative Priority.
		@param PromotionPriority Which promotion should be apply to a product
	*/
	public void setPromotionPriority (int PromotionPriority)
	{
		set_Value (COLUMNNAME_PromotionPriority, Integer.valueOf(PromotionPriority));
	}

	/** Get Relative Priority.
		@return Which promotion should be apply to a product
	  */
	public int getPromotionPriority()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_PromotionPriority);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}
}