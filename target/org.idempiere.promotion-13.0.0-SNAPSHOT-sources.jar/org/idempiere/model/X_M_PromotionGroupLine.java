/******************************************************************************
 * Product: iDempiere ERP & CRM Smart Business Solution                       *
 * Copyright (C) 1999-2012 ComPiere, Inc. All Rights Reserved.                *
 * This program is free software, you can redistribute it and/or modify it    *
 * under the terms version 2 of the GNU General Public License as published   *
 * by the Free Software Foundation. This program is distributed in the hope   *
 * that it will be useful, but WITHOUT ANY WARRANTY, without even the implied *
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.           *
 * See the GNU General Public License for more details.                       *
 * You should have received a copy of the GNU General Public License along    *
 * with this program, if not, write to the Free Software Foundation, Inc.,    *
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.                     *
 * For the text or an alternative of this public license, you may reach us    *
 * ComPiere, Inc., 2620 Augustine Dr. #245, Santa Clara, CA 95054, USA        *
 * or via info@compiere.org or http://www.compiere.org/license.html           *
 *****************************************************************************/
/** Generated Model - DO NOT CHANGE */
package org.idempiere.model;

import java.sql.ResultSet;
import java.util.Properties;
import org.compiere.model.*;

/** Generated Model for M_PromotionGroupLine
 *  @author iDempiere (generated)
 *  @version Release 12 - $Id$ */
@org.adempiere.base.Model(table="M_PromotionGroupLine")
public class X_M_PromotionGroupLine extends PO implements I_M_PromotionGroupLine, I_Persistent
{

	/**
	 *
	 */
	private static final long serialVersionUID = 20240617L;

    /** Standard Constructor */
    public X_M_PromotionGroupLine (Properties ctx, int M_PromotionGroupLine_ID, String trxName)
    {
      super (ctx, M_PromotionGroupLine_ID, trxName);
      /** if (M_PromotionGroupLine_ID == 0)
        {
			setM_Product_ID (0);
			setM_PromotionGroupLine_ID (0);
			setM_PromotionGroup_ID (0);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroupLine (Properties ctx, int M_PromotionGroupLine_ID, String trxName, String ... virtualColumns)
    {
      super (ctx, M_PromotionGroupLine_ID, trxName, virtualColumns);
      /** if (M_PromotionGroupLine_ID == 0)
        {
			setM_Product_ID (0);
			setM_PromotionGroupLine_ID (0);
			setM_PromotionGroup_ID (0);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroupLine (Properties ctx, String M_PromotionGroupLine_UU, String trxName)
    {
      super (ctx, M_PromotionGroupLine_UU, trxName);
      /** if (M_PromotionGroupLine_UU == null)
        {
			setM_Product_ID (0);
			setM_PromotionGroupLine_ID (0);
			setM_PromotionGroup_ID (0);
        } */
    }

    /** Standard Constructor */
    public X_M_PromotionGroupLine (Properties ctx, String M_PromotionGroupLine_UU, String trxName, String ... virtualColumns)
    {
      super (ctx, M_PromotionGroupLine_UU, trxName, virtualColumns);
      /** if (M_PromotionGroupLine_UU == null)
        {
			setM_Product_ID (0);
			setM_PromotionGroupLine_ID (0);
			setM_PromotionGroup_ID (0);
        } */
    }

    /** Load Constructor */
    public X_M_PromotionGroupLine (Properties ctx, ResultSet rs, String trxName)
    {
      super (ctx, rs, trxName);
    }

    /** AccessLevel
      * @return 3 - Client - Org
      */
    protected int get_AccessLevel()
    {
      return accessLevel.intValue();
    }

    /** Load Meta Data */
    protected POInfo initPO (Properties ctx)
    {
      POInfo poi = POInfo.getPOInfo (ctx, Table_ID, get_TrxName());
      return poi;
    }

    public String toString()
    {
      StringBuilder sb = new StringBuilder ("X_M_PromotionGroupLine[")
        .append(get_ID()).append("]");
      return sb.toString();
    }

	public org.compiere.model.I_M_Product getM_Product() throws RuntimeException
	{
		return (org.compiere.model.I_M_Product)MTable.get(getCtx(), org.compiere.model.I_M_Product.Table_ID)
			.getPO(getM_Product_ID(), get_TrxName());
	}

	/** Set Product.
		@param M_Product_ID Product, Service, Item
	*/
	public void setM_Product_ID (int M_Product_ID)
	{
		if (M_Product_ID < 1)
			set_Value (COLUMNNAME_M_Product_ID, null);
		else
			set_Value (COLUMNNAME_M_Product_ID, Integer.valueOf(M_Product_ID));
	}

	/** Get Product.
		@return Product, Service, Item
	  */
	public int getM_Product_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_M_Product_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set Promotion Group Line.
		@param M_PromotionGroupLine_ID Promotion Group Line
	*/
	public void setM_PromotionGroupLine_ID (int M_PromotionGroupLine_ID)
	{
		if (M_PromotionGroupLine_ID < 1)
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroupLine_ID, null);
		else
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroupLine_ID, Integer.valueOf(M_PromotionGroupLine_ID));
	}

	/** Get Promotion Group Line.
		@return Promotion Group Line	  */
	public int getM_PromotionGroupLine_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_M_PromotionGroupLine_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}

	/** Set M_PromotionGroupLine_UU.
		@param M_PromotionGroupLine_UU M_PromotionGroupLine_UU
	*/
	public void setM_PromotionGroupLine_UU (String M_PromotionGroupLine_UU)
	{
		set_Value (COLUMNNAME_M_PromotionGroupLine_UU, M_PromotionGroupLine_UU);
	}

	/** Get M_PromotionGroupLine_UU.
		@return M_PromotionGroupLine_UU	  */
	public String getM_PromotionGroupLine_UU()
	{
		return (String)get_Value(COLUMNNAME_M_PromotionGroupLine_UU);
	}

	public I_M_PromotionGroup getM_PromotionGroup() throws RuntimeException
	{
		return (I_M_PromotionGroup)MTable.get(getCtx(), I_M_PromotionGroup.Table_ID)
			.getPO(getM_PromotionGroup_ID(), get_TrxName());
	}

	/** Set Promotion Group.
		@param M_PromotionGroup_ID Promotion Group
	*/
	public void setM_PromotionGroup_ID (int M_PromotionGroup_ID)
	{
		if (M_PromotionGroup_ID < 1)
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroup_ID, null);
		else
			set_ValueNoCheck (COLUMNNAME_M_PromotionGroup_ID, Integer.valueOf(M_PromotionGroup_ID));
	}

	/** Get Promotion Group.
		@return Promotion Group	  */
	public int getM_PromotionGroup_ID()
	{
		Integer ii = (Integer)get_Value(COLUMNNAME_M_PromotionGroup_ID);
		if (ii == null)
			 return 0;
		return ii.intValue();
	}
}